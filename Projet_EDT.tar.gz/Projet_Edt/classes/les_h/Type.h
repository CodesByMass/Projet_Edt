#ifndef Type_h
#define Type_h

#include <list> 
#include <iterator> 
#include <cmath> 
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
using namespace std;

enum Type
{
	TD, 
	CM, 
	TP
};

#endif
